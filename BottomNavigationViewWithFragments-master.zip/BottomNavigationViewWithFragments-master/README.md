# BottomNavigationViewWithFragments
GYK 401 💃🍓

![alt text](https://firebasestorage.googleapis.com/v0/b/gykutuphanem.appspot.com/o/Screen%20Shot%202019-04-02%20at%2021.37.17.png?alt=media&token=c9766707-e711-4b95-aff6-f71a67d721e6)
